var W3CWebSocket = require('websocket').w3cwebsocket; 
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://sksshouvo:skspor@92@kryptocurrency.vqpyj.mongodb.net/hitbtc?retryWrites=true&w=majority";
var client = new W3CWebSocket('wss://api.hitbtc.com/api/2/ws', '');
var client2 = new W3CWebSocket('wss://api.hitbtc.com/api/2/ws', '');
var count = 0; 
var count2 = 0; 
// data entry function
var data_entry = function(tt){
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("hitbtc");
        //var myobj = { symbol: value.symbol, timestamp: value.timestamp, volumeQuote:value.volumeQuote, volume:value.volume, high:value.high, low:value.low, open:value.open, last:value.last, bid:value.bid, ask:value.ask};
        dbo.collection("tickers").insertOne(tt, function(err, res) {
          if (err) throw err;
          //console.log(key+" document inserted");
        });
      }); 
}
client.onerror = function() {
    console.log('Connection Error');
};
client2.onerror = function() {
  console.log('Connection Error');
};
 
client.onopen = function() {
    console.log('WebSocket Client Connected');
 
    function sendNumber() {
        if (client.readyState === client.OPEN) {
            var toto = '{"method": "subscribeTicker","params": {"symbol": "ETHBTC"},"id": 123}';
            client.send(toto);
            setTimeout(sendNumber, 1000);
        }
    }
    sendNumber();
};

client2.onopen = function() {
  console.log('WebSocket Client Connected');

  function sendNumber2() {
      if (client2.readyState === client2.OPEN) {
          var toto = '{"method": "subscribeTicker","params": {"symbol": "BTCUSD"},"id": 123}';
          client2.send(toto);
          setTimeout(sendNumber2, 1000);
      }
  }
  sendNumber2();
};
 
client.onclose = function() {
    console.log('echo-protocol Client Closed');
};
client2.onclose = function() {
  console.log('echo-protocol Client Closed');
};
 
client.onmessage = function(e) {
count++;
    if (typeof e.data === 'string') {
       var rr = JSON.parse(e.data);
       if(rr.params!=undefined){
        data_entry(rr.params);
        console.log(rr.params.symbol+" no data "+ count);
    }
     
    }
};
client2.onmessage = function(e) {
  count2++;
      if (typeof e.data === 'string') {
        var rr = JSON.parse(e.data);
        if(rr.params!=undefined){
            data_entry(rr.params);
            console.log(rr.params.symbol+" no data "+ count2);
        }
        
      }
  };